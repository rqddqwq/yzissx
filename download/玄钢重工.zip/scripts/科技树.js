const {玄钢核心} = require("blocks/玄钢核心");
const lib = require("base/lib");
const {凯利斯} = require("planets/凯利斯");
凯利斯.techTree = TechTree.nodeRoot( "凯利斯", 玄钢核心, true, run(() => {}));